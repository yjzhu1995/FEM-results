This is an example of calculating velocity for "benchmark_4" with a fault length of 1000 km.

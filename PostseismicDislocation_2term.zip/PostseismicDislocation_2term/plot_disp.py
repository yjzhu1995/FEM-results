import numpy as np
import pygmt

year = ['70 yr', '100', '125', '150', '175', '200', '250', '300', 
       '350', '400', '450', '500', '550', '600']

# data
fl = './disp/disp_2terms_70-600.dat'

W = np.cos(15*np.pi/180)*100
deg2km = np.pi*6371/180

defor = np.loadtxt(fl, skiprows=1)
defor[:,0] = defor[:,0]*deg2km

for k in range(len(year)):
	defor[:,3*(k+1)+2] = (defor[:,3*(k+1)+2]-defor[:,2])*100
	defor[:,3*(k+1)+3] = (defor[:,3*(k+1)+3]-defor[:,3])*100
	defor[:,3*(k+1)+4] = (defor[:,3*(k+1)+4]-defor[:,4])*100
	

fig = pygmt.Figure()

pygmt.config(MAP_TICK_LENGTH=-0.15, FONT_TITLE="16p", FONT_LABEL="12p", FONT_ANNOT="12p")

# plot horizontal displacement
region = [-150, 250, -30, 30]
fig.basemap(region=region, projection="X4i/2i", frame=["WesN", "xa50f25+l\"distance from trench (km)\"", "ya10f10+l\"Ux*100/slip\""], yshift="4i")
# x = [600, 600, 900, 900, 600]
# y = [20, -20, -20, 20, 20]
# fig.plot(x=x, y=y, pen="0.01p,white", color="lightblue", transparency=50)

pygmt.makecpt(cmap="rainbow", series=[0, len(year)-1, 1], color_model="+c70,100,125,150,175,200,250,300,350,400,450,500,550,600")

for k in range(len(year)):
	fig.plot(x=defor[:,0], y=defor[:,3*(k+1)+2], cmap=True, zvalue=k, pen="0.25p,+z,-")

# fig.legend(position="JBL+jBL+o0.2c", box=False)
# fig.text(x=-1.75, y=-17, text="(a)")


# plot vertical displacement
region = [-150, 250, -80, 50]
fig.basemap(region=region, projection="X4i/2i", frame=["Wesn", "xa50f25", "ya20f20+l\"Uz*100/slip\""], yshift="-2.3i")

for k in range(len(year)):
	fig.plot(x=defor[:,0], y=defor[:,3*(k+1)+4], cmap=True, zvalue=k, pen="0.25p,+z,-")

fig.colorbar(position="+o0i/-0.25i+h+w4i")

# fig.psconvert(dpi="720",prefix="benchmark_4_FL=1000km",fmt="f")
# fig.psconvert(dpi="720",prefix="benchmark_4_FL=1000km",fmt="E")
fig.psconvert(dpi="720",prefix="benchmark_4_FL=1000km_70-600",fmt="G")
# or 
# fig.savefig("exp.eps",dpi="720")
